// JavaScript for the accordion functionality
const accBtn = document.querySelector('.accordion-btn');
const panel = document.querySelector('.panel');

accBtn.addEventListener('click', function() {
    this.classList.toggle('active');
    if (panel.style.display === 'block') {
        panel.style.display = 'none';
    } else {
        panel.style.display = 'block';
    }
});

const radioButtons = document.querySelectorAll('input[type="radio"]');

// Function to allow multiple selections in radio buttons
function enableMultipleSelection(event) {
    const clickedRadioButton = event.target;
    if (clickedRadioButton.checked) {
        // Uncheck the already checked radio button of the same name
        radioButtons.forEach(radio => {
            if (radio !== clickedRadioButton && radio.name === clickedRadioButton.name) {
                radio.checked = false;
            }
        });
    }
}

// Attach the function to each radio button
radioButtons.forEach(radioButton => {
    radioButton.addEventListener('click', enableMultipleSelection);
});