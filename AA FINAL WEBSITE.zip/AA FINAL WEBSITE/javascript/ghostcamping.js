let slideIndex = 0;

function moveSlide(n) {
  showSlide(slideIndex += n);
}

function showSlide(n) {
  const slides = document.querySelector('.slides');
  if (n > 2) { slideIndex = 0; }
  if (n < 0) { slideIndex = 2; }
  slides.style.transform = `translateX(${-33.33 * slideIndex}%)`;
}

// Automatic slide change every 3 seconds
setInterval(function() {
  moveSlide(1);
}, 6000);